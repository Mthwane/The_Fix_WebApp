using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FashionFix.Web.Models.Entities;

public enum OrderType
{
    POS,     // In-store till transaction
    Online   // Customer web checkout
}

public enum OrderStatus
{
    Pending,
    Processing,
    Completed,
    Shipped,
    Delivered,
    Cancelled,
    Returned
}

public enum PaymentMethod
{
    Cash,
    CreditCard,
    DebitCard
}

public class Order
{
    [Key]
    public int OrderId { get; set; }

    [Required, MaxLength(30)]
    public string OrderNumber { get; set; } = string.Empty; // human-readable receipt / order ref

    // Customer who placed / owns the order (nullable for walk-in cash sales with no account)
    public string? CustomerId { get; set; }
    public ApplicationUser? Customer { get; set; }

    // Employee who processed the sale at the till
    public string? ProcessedByUserId { get; set; }
    public ApplicationUser? ProcessedByUser { get; set; }

    public OrderType OrderType { get; set; }
    public OrderStatus Status { get; set; } = OrderStatus.Pending;
    public PaymentMethod PaymentMethod { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal SubTotal { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal DiscountTotal { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal TaxTotal { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal GrandTotal { get; set; }

    public DateTime DateCreated { get; set; } = DateTime.UtcNow;
    public DateTime? DateFulfilled { get; set; }

    // --- Delivery address (Online orders only - null for in-store POS sales) ---
    // Snapshotted from the customer's chosen CustomerAddress at checkout time, not a
    // foreign key to it, so editing or deleting that saved address later never rewrites
    // where a past order actually shipped to.
    [MaxLength(100)]
    public string? DeliveryRecipientName { get; set; }

    [MaxLength(20)]
    public string? DeliveryPhoneNumber { get; set; }

    [MaxLength(200)]
    public string? DeliveryAddressLine1 { get; set; }

    [MaxLength(200)]
    public string? DeliveryAddressLine2 { get; set; }

    [MaxLength(100)]
    public string? DeliveryCity { get; set; }

    [MaxLength(100)]
    public string? DeliveryProvince { get; set; }

    [MaxLength(10)]
    public string? DeliveryPostalCode { get; set; }

    // --- Navigation ---
    public ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
}

public class OrderItem
{
    [Key]
    public int OrderItemId { get; set; }

    public int OrderId { get; set; }
    public Order Order { get; set; } = null!;

    // Denormalized onto the OrderItem (rather than reached only via the variant) so
    // reporting/grouping by style never needs to join through ProductVariant, and so a
    // historical order still resolves to a Product even in the rare case its variant is
    // later deactivated.
    public int ProductId { get; set; }
    public Product Product { get; set; } = null!;

    /// <summary>The exact size/colour sold. Nullable only so existing pre-variant historical
    /// data (if any) still loads; every new sale always sets this.</summary>
    public int? ProductVariantId { get; set; }
    public ProductVariant? ProductVariant { get; set; }

    public int Quantity { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal UnitPrice { get; set; } // price at time of sale

    [Column(TypeName = "decimal(18,2)")]
    public decimal LineTotal { get; set; }
}