﻿using FashionFix.Web.Data;
using FashionFix.Web.Models.Entities;
using FashionFix.Web.Models.ViewModels;
using FashionFix.Web.Security;
using FashionFix.Web.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Globalization;
using System.Net;
using The__Fix_WebApp.Services;

namespace FashionFix.Web.Controllers;

/// <summary>
/// Handles the Paystack redirect back into the app. This is where an Order actually
/// gets created - never in ShopController.Checkout - so nothing is marked paid,
/// and no stock is decremented, until the gateway has confirmed the money moved.
/// (The other place an Order can be created is ShopController.Checkout itself, but only
/// for the "charge a saved card instantly" path, which never leaves this app at all.)
/// </summary>
[Authorize(Roles = "Customer")]
public class PaymentsController : Controller
{
    private readonly IRewardsService _rewards;
    private readonly ApplicationDbContext _context;
    private readonly IOrderFulfillmentService _orderFulfillment;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly ILogger<PaymentsController> _logger;

    public PaymentsController(
        ApplicationDbContext context,
        IOrderFulfillmentService orderFulfillment,
        UserManager<ApplicationUser> userManager,
        ILogger<PaymentsController> logger)
    {
        _context = context;
        _orderFulfillment = orderFulfillment;
        _userManager = userManager;
        _logger = logger;
    }

    // GET: /Payments/Callback?reference=WEB-xxxx&trxref=WEB-xxxx
    // Paystack sends both "reference" and "trxref" with the same value - either is fine.
    [HttpGet]
    public async Task<IActionResult> Callback(
        string? reference, string? trxref, [FromServices] IPaymentService payments)
    {
        var actualReference = reference ?? trxref;
        var pendingReference = HttpContext.Session.GetString("PendingPaymentReference");
        var pendingMethodRaw = HttpContext.Session.GetString("PendingPaymentMethod");
        var pendingAddressId = HttpContext.Session.GetInt32("PendingAddressId");
        var pendingSaveCard = HttpContext.Session.GetString("PendingSaveCard") == "true";

        if (string.IsNullOrEmpty(actualReference) || actualReference != pendingReference)
        {
            this.ToastError("This payment session doesn't match your cart - please try checking out again.");
            return RedirectToAction("Cart", "Shop");
        }

        var verifyResult = await payments.VerifyTransactionAsync(actualReference);

        if (!verifyResult.Success)
        {
            this.ToastError($"Payment was not completed: {verifyResult.ErrorMessage}");
            return RedirectToAction("Cart", "Shop");
        }

        var cart = SessionCart.GetSnapshot(HttpContext.Session, actualReference);
        if (cart is null || cart.Lines.Count == 0)
        {
            // Verified payment but no snapshot left in session - shouldn't normally happen,
            // but don't silently lose a paid transaction: log it loudly for manual follow-up.
            _logger.LogError(
                "Payment {Reference} verified for {Amount:C} but no cart snapshot was found in session.",
                actualReference, verifyResult.AmountRands);
            this.ToastError("Your payment succeeded but your cart session expired. Please contact support with reference " + actualReference);
            return RedirectToAction("Index", "Shop");
        }

        // Reconcile what was actually charged against what this snapshot says the order
        // should cost. The snapshot closes the "edit your cart while sitting on Paystack's
        // page" window, but this check is the belt-and-braces backstop: it catches anything
        // that could still cause a mismatch (a clock/rounding edge case, a gateway anomaly)
        // rather than ever silently creating an order for a different amount than was paid.
        var pendingPoints = HttpContext.Session.GetInt32("PendingPointsRedeemed") ?? 0;
        var pendingPointsDiscount = 0m;
        if (pendingPoints > 0)
            decimal.TryParse(HttpContext.Session.GetString("PendingPointsDiscount"), NumberStyles.Number, CultureInfo.InvariantCulture, out pendingPointsDiscount);

        var expectedVat = TaxSettings.CalculateVat(cart.SubTotal, pendingPointsDiscount);
        var expectedTotal = cart.SubTotal - pendingPointsDiscount + expectedVat;
        if (Math.Abs(expectedTotal - verifyResult.AmountRands) > 0.01m)
        {
            _logger.LogError(
                "Payment {Reference} verified for {Paid:C} but the reconciled cart total is {Expected:C} - refusing to create an order automatically.",
                actualReference, verifyResult.AmountRands, expectedTotal);
            this.ToastError($"Your payment succeeded but the amount doesn't match your order - nothing has been charged incorrectly, but we need to check this manually. Please contact support with reference {actualReference}.");
            return RedirectToAction("Index", "Shop");
        }

        // Final stock re-check - time has passed while the customer was on Paystack's page.
        // One IN-clause query for the whole cart instead of one FindAsync per line.
        var checkoutVariantIds = cart.Lines.Select(l => l.VariantId).Distinct().ToList();
        var checkoutVariants = await _context.ProductVariants
            .AsNoTracking()
            .Include(v => v.Product)
            .Where(v => checkoutVariantIds.Contains(v.ProductVariantId))
            .ToDictionaryAsync(v => v.ProductVariantId);

        foreach (var line in cart.Lines)
        {
            if (!checkoutVariants.TryGetValue(line.VariantId, out var variant) || !variant.IsActive || !variant.Product.IsActive || variant.StockQuantity < line.Quantity)
            {
                _logger.LogError(
                    "Payment {Reference} verified for {Amount:C} but stock check failed for variant {VariantId}.",
                    actualReference, verifyResult.AmountRands, line.VariantId);
                this.ToastError($"Your payment succeeded but '{line.Name}' is no longer available. Please contact support with reference {actualReference} for a refund.");
                return RedirectToAction("Index", "Shop");
            }
        }

        var user = await _userManager.GetUserAsync(User);
        if (user is null) return NotFound();

        var paymentMethod = Enum.TryParse<PaymentMethod>(pendingMethodRaw, out var pm)
            ? pm
            : PaymentMethod.CreditCard;

        CustomerAddress? deliveryAddress = pendingAddressId.HasValue
            ? await _context.CustomerAddresses.FirstOrDefaultAsync(a => a.CustomerAddressId == pendingAddressId && a.CustomerId == user.Id)
            : null;

        if (pendingPoints > 0)
        {
            var redeemResult = await _rewards.RedeemAsync(user.Id, pendingPoints, actualReference);
            if (!redeemResult.Success)
            {
                _logger.LogError("Payment {Reference} verified but redeeming {Points} points failed: {Error}",
                    actualReference, pendingPoints, redeemResult.ErrorMessage);
                this.ToastError($"Your payment succeeded but we couldn't apply your reward points ({redeemResult.ErrorMessage}). Please contact support with reference {actualReference}.");
                return RedirectToAction("Index", "Shop");
            }
        }

        var order = await _orderFulfillment.CreateOnlineOrderAsync(user, cart, paymentMethod, actualReference, deliveryAddress, pendingPointsDiscount);

        // If the customer ticked "save this card" and the bank allows the card to be
        // charged again later, remember it for next time - dedup by AuthorizationCode so
        // paying with the same card twice doesn't create two entries.
        if (pendingSaveCard && verifyResult.Authorization is { Reusable: true } auth)
        {
            var alreadySaved = await _context.CustomerPaymentMethods
                .AnyAsync(p => p.CustomerId == user.Id && p.AuthorizationCode == auth.AuthorizationCode);

            if (!alreadySaved)
            {
                var hasAnyCard = await _context.CustomerPaymentMethods.AnyAsync(p => p.CustomerId == user.Id);
                _context.CustomerPaymentMethods.Add(new CustomerPaymentMethod
                {
                    CustomerId = user.Id,
                    AuthorizationCode = auth.AuthorizationCode,
                    Last4 = auth.Last4,
                    CardType = auth.CardType,
                    ExpiryMonth = auth.ExpiryMonth,
                    ExpiryYear = auth.ExpiryYear,
                    Bank = auth.Bank,
                    IsDefault = !hasAnyCard // first saved card becomes the default automatically
                });
                await _context.SaveChangesAsync();
            }
        }

        SessionCart.Clear(HttpContext.Session);
        SessionCart.ClearSnapshot(HttpContext.Session, actualReference);
        HttpContext.Session.Remove("PendingPaymentReference");
        HttpContext.Session.Remove("PendingPaymentMethod");
        HttpContext.Session.Remove("PendingAddressId");
        HttpContext.Session.Remove("PendingSaveCard");
        HttpContext.Session.Remove("PendingPointsRedeemed");
        HttpContext.Session.Remove("PendingPointsDiscount");

        this.ToastSuccess($"Payment confirmed - order {order.OrderNumber} placed for {order.GrandTotal:C}.");

        return RedirectToAction("Confirmation", "Shop", new { id = order.OrderId });
    }
}